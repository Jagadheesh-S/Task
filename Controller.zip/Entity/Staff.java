package com.example.demo;

import java.time.LocalDate;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.*;
import jakarta.persistence.JoinColumn;

@Entity
@Table(name="Staff_Table")
public class Staff {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="Staff_ID")
	private long staffid;
	
	@Column(name="Staff_Name")
	private String staffName;
	
	@Column(name="Gender")
	private String gender;
	
	@Temporal(TemporalType.DATE)
	@Column(name="Date_Of_Birth")
	private Date dateOfbirth;
	
	@Column(name="Address")
	private String address;
	
	@Column(name="Phone_Number")
	private long phoneNumber;
	
	@Column(name="Email")
	private String email;
	
	@Column(name="Job_Title")
	private String jobtitle;
	
	@Column(name="Joining_Date")
	@Temporal(TemporalType.DATE)
	private LocalDate joindate=LocalDate.now();
	
	@Column(name="Salary")
	private double salary;
	
	@JoinColumn(name="departmentid")
	private long departmentid;
	
	public Staff() {
		
	}

	public Staff(long staffid, String staffName, String gender, Date dateOfbirth, String address, long phoneNumber,
			String email, String jobtitle, LocalDate joindate, double salary, long departmentid) {
		super();
		this.staffid = staffid;
		this.staffName = staffName;
		this.gender = gender;
		this.dateOfbirth = dateOfbirth;
		this.address = address;
		this.phoneNumber = phoneNumber;
		this.email = email;
		this.jobtitle = jobtitle;
		this.joindate = joindate;
		this.salary = salary;
		this.departmentid = departmentid;
	}

	public long getStaffid() {
		return staffid;
	}

	public void setStaffid(long staffid) {
		this.staffid = staffid;
	}

	public String getStaffName() {
		return staffName;
	}

	public void setStaffName(String staffName) {
		this.staffName = staffName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Date getDateOfbirth() {
		return dateOfbirth;
	}

	public void setDateOfbirth(Date dateOfbirth) {
		this.dateOfbirth = dateOfbirth;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getJobtitle() {
		return jobtitle;
	}

	public void setJobtitle(String jobtitle) {
		this.jobtitle = jobtitle;
	}

	public LocalDate getJoindate() {
		return joindate;
	}

	public void setJoindate(LocalDate joindate) {
		this.joindate = joindate;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public long getDepartmentid() {
		return departmentid;
	}

	public void setDepartmentid(long departmentid) {
		this.departmentid = departmentid;
	}
	
	
}
