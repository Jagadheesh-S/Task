package com.example.demo;

import java.util.Date;
import java.util.List;

import jakarta.persistence.*;

@Entity
public class Patient {


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="PatientID")
	private long patientid;
	
	@Column(name="Patient_Name")
	private String patientName;
	
	@Column(name="Gender")
	private String gender;
	
	@Temporal(TemporalType.DATE)
	@Column(name="Date_Of_Birth")
	private Date dateOfbirth;
	
	@Column(name="Address")
	private String address;
	
	@Column(name="Phone_Number")
	private long phoneNumber;
	
	@Column(name="Email")
	private String email;
	
	@Column(name="Next_Of_Kin_Name")
	private String kinName;
	
	@Column(name="Next_Of_Kin_Phone")
	private long kinPhone;
	
	@OneToMany()
	@JoinColumn(name="patientid" ,referencedColumnName ="PatientID")
	private List<Appointment> appointment;
	
	@OneToMany
	@JoinColumn(name="patientid")
	private List<Billing> billing;

	public Patient() {
		
	}

	public Patient(long patientid, String patientName, String gender, Date dateOfbirth, String address,
			long phoneNumber, String email,  String kinName, long kinPhone,
			List<Appointment> appointment) {
		super();
		this.patientid = patientid;
		this.patientName = patientName;
		this.gender = gender;
		this.dateOfbirth = dateOfbirth;
		this.address = address;
		this.phoneNumber = phoneNumber;
		this.email = email;
		this.kinName = kinName;
		this.kinPhone = kinPhone;
		this.appointment = appointment;
	}

	public long getPatientid() {
		return patientid;
	}

	public void setPatientid(long patientid) {
		this.patientid = patientid;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Date getDateOfbirth() {
		return dateOfbirth;
	}

	public void setDateOfbirth(Date dateOfbirth) {
		this.dateOfbirth = dateOfbirth;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getKinName() {
		return kinName;
	}

	public void setKinName(String kinName) {
		this.kinName = kinName;
	}

	public long getKinPhone() {
		return kinPhone;
	}

	public void setKinPhone(long kinPhone) {
		this.kinPhone = kinPhone;
	}

	

	
}
