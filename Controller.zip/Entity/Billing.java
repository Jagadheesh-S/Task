package com.example.demo;

import java.time.LocalDate;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
public class Billing {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="Billing_Id")
	private long billingid;
	
	@Column(name="CheckIn_Date")
	@Temporal(TemporalType.DATE)
	private LocalDate appointmentDate=LocalDate.now();
	
	@Column(name="Discharge_Date")
	@Temporal(TemporalType.DATE)
	private LocalDate discharegeDate;
	
	@Column(name="TotalAmount")
	private double totalAmount;
	
	
	@Column(name="Payment_Method")
	private String paymentMethod;
	
	@JoinColumn(name="roomnumber")
	private long roomnumber;

	@JoinColumn(name="patientid")
	private long patientid;
	
	public Billing() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Billing(long billingid, LocalDate appointmentDate, LocalDate discharegeDate, double totalAmount,
			String paymentMethod, long roomnumber, long patientid) {
		super();
		this.billingid = billingid;
		this.appointmentDate = appointmentDate;
		this.discharegeDate = discharegeDate;
		this.totalAmount = totalAmount;
		this.paymentMethod = paymentMethod;
		this.roomnumber = roomnumber;
		this.patientid = patientid;
	}

	public long getBillingid() {
		return billingid;
	}

	public void setBillingid(long billingid) {
		this.billingid = billingid;
	}

	public LocalDate getAppointmentDate() {
		return appointmentDate;
	}

	public void setAppointmentDate(LocalDate appointmentDate) {
		this.appointmentDate = appointmentDate;
	}

	public LocalDate getDischaregeDate() {
		return discharegeDate;
	}

	public void setDischaregeDate(LocalDate discharegeDate) {
		this.discharegeDate = discharegeDate;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public long getRoomnumber() {
		return roomnumber;
	}

	public void setRoomnumber(long roomnumber) {
		this.roomnumber = roomnumber;
	}

	public long getPatientid() {
		return patientid;
	}

	public void setPatientid(long patientid) {
		this.patientid = patientid;
	}
}