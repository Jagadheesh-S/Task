package com.example.demo;

import java.time.LocalDate;

import jakarta.persistence.*;

@Entity(name="appointment")
public class Appointment {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="Appointment_ID")
	private int appointmentid;
	
	@Column(name="Appointment_Date")
	@Temporal(TemporalType.DATE)
	private LocalDate appointmentDate;
	
	@Column(name="Diagnosis")
	private String diagnosis;
	
	@Column(name="Type_Of_Treatment")
	private  String typeOftreatement;
	
	@Column(name="Appointment_Status")
	 private String appointmentStatus;
	
	@JoinColumn(name="patientid")
	private long patientid;
	 
	@JoinColumn(name="doctorId")
	private long doctorId;

	public Appointment() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Appointment(int appointmentid, LocalDate appointmentDate, String diagnosis, String typeOftreatement,
			String appointmentStatus, long patientid, long doctorId) {
		super();
		this.appointmentid = appointmentid;
		this.appointmentDate = appointmentDate;
		this.diagnosis = diagnosis;
		this.typeOftreatement = typeOftreatement;
		this.appointmentStatus = appointmentStatus;
		this.patientid = patientid;
		this.doctorId = doctorId;
	}

	public int getAppointmentid() {
		return appointmentid;
	}

	public void setAppointmentid(int appointmentid) {
		this.appointmentid = appointmentid;
	}

	public LocalDate getAppointmentDate() {
		return appointmentDate;
	}

	public void setAppointmentDate(LocalDate appointmentDate) {
		this.appointmentDate = appointmentDate;
	}

	public String getDiagnosis() {
		return diagnosis;
	}

	public void setDiagnosis(String diagnosis) {
		this.diagnosis = diagnosis;
	}

	public String getTypeOftreatement() {
		return typeOftreatement;
	}

	public void setTypeOftreatement(String typeOftreatement) {
		this.typeOftreatement = typeOftreatement;
	}

	public String getAppointmentStatus() {
		return appointmentStatus;
	}

	public void setAppointmentStatus(String appointmentStatus) {
		this.appointmentStatus = appointmentStatus;
	}

	public long getPatientid() {
		return patientid;
	}

	public void setPatientid(long patientid) {
		this.patientid = patientid;
	}

	public long getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(long doctorId) {
		this.doctorId = doctorId;
	}
	
			
}
