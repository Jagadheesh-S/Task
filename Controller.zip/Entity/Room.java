package com.example.demo;
 
import java.util.List;

import org.springframework.stereotype.Component;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;

@Component("roomclass")
@Entity
public class Room {

	@Id
	@Column(name="Room_Number")
	private long roomnumber;
	
	@Column(name="Room_Type")
	private String roomType;
	
	@Column(name="Room_Status")
	private boolean roomStatus;
	
	@Column(name="Room_Rate")
	private double roomRate;
	
	@OneToMany
	@JoinColumn(name="roomnumber")
	private List<Billing> billing;
	
	public Room() {
		
	}

	public Room(long roomnumber, String roomType, boolean roomStatus, double roomRate, List<Billing> billing) {
		super();
		this.roomnumber = roomnumber;
		this.roomType = roomType;
		this.roomStatus = roomStatus;
		this.roomRate = roomRate;
		this.billing = billing;
	}

	public long getRoomnumber() {
		return roomnumber;
	}

	public void setRoomnumber(long roomnumber) {
		this.roomnumber = roomnumber;
	}

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public boolean isRoomStatus() {
		return roomStatus;
	}

	public void setRoomStatus(boolean roomStatus) {
		this.roomStatus = roomStatus;
	}

	public double getRoomRate() {
		return roomRate;
	}

	public void setRoomRate(double roomRate) {
		this.roomRate = roomRate;
	}

	public List<Billing> getBilling() {
		return billing;
	}

	public void setBilling(List<Billing> billing) {
		this.billing = billing;
	}

		
}