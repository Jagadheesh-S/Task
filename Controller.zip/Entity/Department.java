package com.example.demo;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;

@Entity
public class Department {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="Department_ID")
	private long departmentid;
	
	@Column(name="Department_Name")
	private String department_Name;
	
	@Column(name="Department_Description")
	private String department_Description;

	@OneToMany()
	@JoinColumn(name="departmentid")
	private List<Doctor> doctor;
	
	 @OneToMany()
	 @JoinColumn(name="departmentid")
	 private List<Staff> staff;

	public Department() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Department(long departmentid, String department_Name, String department_Description, List<Doctor> doctor,
			List<Staff> staff) {
		super();
		this.departmentid = departmentid;
		this.department_Name = department_Name;
		this.department_Description = department_Description;
		this.doctor = doctor;
		this.staff = staff;
	}

	public long getDepartmentid() {
		return departmentid;
	}

	public void setDepartmentid(long departmentid) {
		this.departmentid = departmentid;
	}

	public String getDepartment_Name() {
		return department_Name;
	}

	public void setDepartment_Name(String department_Name) {
		this.department_Name = department_Name;
	}

	public String getDepartment_Description() {
		return department_Description;
	}

	public void setDepartment_Description(String department_Description) {
		this.department_Description = department_Description;
	}

	
	
}
