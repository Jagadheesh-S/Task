package com.example.demo;

import java.util.Date;
import java.util.List;

import jakarta.persistence.*;

@Entity
public class Doctor {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="Doctor_ID")
	private long doctorId;
	
	@Column(name="Doctor_Name")
	private String doctorName;
	
	@Column(name="Gender")
	private String gender;
	
	@Column(name="Date_Of_Birth")
	@Temporal(TemporalType.DATE)
	private Date dateOfbirth;
	
	@Column(name="Address")
	private String address;
	
	@Column(name="Phone_Number")
	private long phoneNumber;
	
	@Column(name="Email")
	private String email;
	
	@JoinColumn(name="departmentid")
	private long departmentid;
	
	@OneToMany()
	@JoinColumn(name="doctorId")
	private List<Appointment> appointment;
	
	public Doctor() {
		
	}
	public Doctor(long doctorId, String doctorName, String gender, Date dateOfbirth, String address, long phoneNumber,
			String email, long departmentid) {
		
		this.doctorId = doctorId;
		this.doctorName = doctorName;
		this.gender = gender;
		this.dateOfbirth = dateOfbirth;
		this.address = address;
		this.phoneNumber = phoneNumber;
		this.email = email;
		this.departmentid = departmentid;
	}
	public long getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(long doctorId) {
		this.doctorId = doctorId;
	}
	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Date getDateOfbirth() {
		return dateOfbirth;
	}
	public void setDateOfbirth(Date dateOfbirth) {
		this.dateOfbirth = dateOfbirth;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public long getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public long getDepartmentid() {
		return departmentid;
	}
	public void setDepartmentid(long departmentid) {
		this.departmentid = departmentid;
	}
	

}
