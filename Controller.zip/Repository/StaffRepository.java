package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Staff;

public interface StaffRepository extends JpaRepository <Staff , Long>{

}
