package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Billing;
import com.example.demo.Room;


public interface BillingRepository extends JpaRepository <Billing , Long>{

	

}
