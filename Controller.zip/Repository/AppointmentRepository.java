package com.example.demo.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.example.demo.Appointment;


public interface AppointmentRepository extends JpaRepository <Appointment , Integer>{
	
	@Query(value="SELECT a.doctor_id as Did, a.patientid as Pid, a.appointment_status as Status FROM appointment a WHERE a.appointment_date =:appointmentdate",nativeQuery=true)
	List<Map<String,Object>> findByDate(LocalDate appointmentdate);
	
	@Query("SELECT a.patientid as id,a.typeOftreatement as type ,a.diagnosis as diagnosis FROM appointment a WHERE a.doctorId = :id ")
	List<Map<String,Object>> findByDocID(long id);
	
	@Query(value="SELECT a.diagnosis as Diagnosis, a.type_of_treatment as TypeOfTreatement, p.patient_name as PatientName FROM appointment a "
			+ "left join patient p on p.patientid = a.patientid WHERE a.doctor_id=:id",nativeQuery=true)
	List<Map<String,Object>>findbydoc(long id);
}
  