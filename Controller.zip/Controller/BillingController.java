package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Billing;
import com.example.demo.Services.BillingService;

@RestController
public class BillingController {

	@Autowired
	private BillingService billSer;
	 
	@PostMapping("/addBill")
	public Billing saveBill(@RequestBody Billing bill)
	{
		return billSer.addBill(bill);
	}
	
	@PostMapping("/addBills")
	public List<Billing> saveBills(@RequestBody List<Billing> bill)
	{
		return billSer.addBills(bill);
	}
	
	@GetMapping("/getBill")
	public List<Billing> findBill()
	{
		return billSer.findBill();
	}
	
	@GetMapping("/getBill/{id}")
	public Billing findBillById(@PathVariable long id)
	{
		return billSer.findById(id);
	}
	
	@DeleteMapping("/deleteBill/{id}")
	public String deleteBill(@PathVariable long id)
	{
		return billSer.deleteBill(id);
	}
	
	@PutMapping("/updateBill")
	public Billing updateBill(@RequestBody Billing bill)
	{
		return billSer.putBill(bill);
	}
}
