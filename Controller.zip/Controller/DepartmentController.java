package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Department;
import com.example.demo.Services.DepartmentService;

@RestController
public class DepartmentController {

		@Autowired
		private DepartmentService DepSer;
		
		@PostMapping("/addDepartment")
		public Department addDepartment(@RequestBody Department Dep)
		{
			return DepSer.saveDepartment(Dep);
		}
		@PostMapping("/addDepartments")
		public List<Department> addDepartments(@RequestBody List<Department> Deps)
		{
			return DepSer.saveDepartments(Deps);
		}
		 @GetMapping("/getDepartment")
		 public List<Department> findAllDepartment() {
		        return DepSer.getDepartment();
		    }

		    @GetMapping("/DepartmentById/{id}")
		    public Department findDepartmentsById(@PathVariable long id) {
		        return DepSer.getDepartment(id); 
		    }

		    @PutMapping("/update")
		    public Department updateDepartment(@RequestBody Department Dep) {
		        return DepSer.updatDepartment(Dep);
		    }

		    @DeleteMapping("/delete/{id}")
		    public String deleteDepartment(@PathVariable long id) {
		        return DepSer.deleteDepartment(id);
		    }

	}


