package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Patient;
import com.example.demo.Services.PatientService;

@RestController
public class PatientController {

	@Autowired
	private PatientService patSer;

	@PostMapping("/addPatient")
	public Patient savePatient(@RequestBody Patient patient)
	{
		return patSer.addPatient(patient);
	}
	
	@PostMapping("/addPatients")
	public List<Patient> savePatients(@RequestBody List<Patient> patient)
	{
		return patSer.addPatients(patient);
	}
	
	@GetMapping("/getPatient")
	public List<Patient> findPatient()
	{
		return patSer.getPatient();
	}
	
	@GetMapping("/getPatientById/{id}")
	public Patient findById(@PathVariable long id)
	{
		return patSer.getPatientById(id);
	}
	
	@DeleteMapping("/deletePatient/{id}")
	public String deletePatient(@PathVariable long id)
	{
		return patSer.deletePatient(id);
	}
	
	@PutMapping("/updatePatient")
	public Patient updatePatient(@RequestBody Patient patint)
	{
		return patSer.updatePatient(patint);
	}
}
