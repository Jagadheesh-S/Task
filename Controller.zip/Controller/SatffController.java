package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Staff;
import com.example.demo.Services.StaffService;

@RestController
public class SatffController {

	@Autowired
	private StaffService staSer;
	
	@PostMapping("/addStaff")
	public Staff addStaff(@RequestBody Staff staff) {
		return staSer.saveStaff(staff);
	}
	
	@PostMapping("/addStaffs")
	public List<Staff> addStaffs(@RequestBody List<Staff> staff)
	{
		return staSer.saveStaffs(staff);
	}
	
	@GetMapping("/getStaff")
	public List<Staff> findSaff()
	{
		return staSer.getStaff();
	}
	
	@GetMapping("/getStaffById/{id}")
	public Staff findById(@PathVariable long id)
	{
		return staSer.getStaffById(id);
	}
	
	@DeleteMapping("/stadelete/{id}")
	public String deleteStaff(@PathVariable long id)
	{
		return staSer.deleteStaff(id);
	}
	
	@PutMapping("/staupdate")
	public Staff updateStaff(@RequestBody Staff staff)
	{
		return staSer.updateStaff(staff);
	}
}
