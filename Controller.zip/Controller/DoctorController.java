package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Doctor;
import com.example.demo.Services.DoctorService;

	@RestController
	public class DoctorController {

		@Autowired
		private DoctorService docSer;
		
		@PostMapping("/addDoctor")
		public Doctor addDoctor(@RequestBody Doctor doctor) {
			return docSer.saveDoctor(doctor);
		}
		
		@PostMapping("/addDoctors")
		public List<Doctor> addDoctors(@RequestBody List<Doctor> doctor)
		{
			return docSer.saveDoctors(doctor);
		}
		
		@GetMapping("/getDoctor")
		public List<Doctor> findDoctor()
		{
			return docSer.getDoctor();
		}
		
		@GetMapping("/getDoctorById/{id}")
		public Doctor findById(@PathVariable long id)
		{
			return docSer.getDoctorById(id);
		}
		
		@DeleteMapping("/docdelete/{id}")
		public String deleteDoctor(@PathVariable long id)
		{
			return docSer.deleteDoctor(id);
		}
		
		@PutMapping("/docupdate")
		public Doctor updateDoctor(@RequestBody Doctor doctor)
		{
			return docSer.updateDoctor(doctor);
		}
	}


