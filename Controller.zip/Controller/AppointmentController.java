package com.example.demo.Controller;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Appointment;
import com.example.demo.Services.AppointmentService;

@RestController
public class AppointmentController {

	@Autowired
	private AppointmentService appSer;
	
	@PostMapping("/addAppointment")
	public Appointment saveApp(@RequestBody Appointment app)
	{
		return appSer.addApp(app);
	}
	
	@PostMapping("/addAppointments")
	public List<Appointment> saveApps(@RequestBody List<Appointment> apps)
	{
		return appSer.addApps(apps);
	}
	
	@GetMapping("/getAppointmant")
	public List<Appointment> findapps()
	{
		return appSer.findapp();
		}
	
	@GetMapping("/getAppointmentById/{id}")
	public Appointment findappByID(@PathVariable int id)
	{
		return appSer.findById(id);
	}
	
	@GetMapping("/getAppointmentDate/{appointmentDate}")
	public List<Map<String, Object>> finddate(@PathVariable("appointmentDate") String appointmentDate)
	{
		LocalDate localdate = LocalDate.parse(appointmentDate);
		return appSer.findappByDate(localdate);
	}
	
	@GetMapping("/getdetailsBydoctorID/DoctorID/{id}")
	public List<Map<String,Object>> findByDocid(@PathVariable long id)
	{
		return appSer.findappByDocID(id);
	}
	
	@GetMapping("/getdetailsBydoctordetailsID/DoctorID/{id}")
	public List<Map<String,Object>> findByDocdetails(@PathVariable long id)
	{
		return appSer.getdocdetails(id);
	}
	
	@DeleteMapping("/deleteAppointment/{id}")
	public String deleteById(@PathVariable int id)
	{
		return appSer.delete(id);
	}
	
	@PutMapping("/updateAppointment")
	public Appointment updateApp(@RequestBody Appointment app)
	{
		return appSer.putApp(app);
	}
}

