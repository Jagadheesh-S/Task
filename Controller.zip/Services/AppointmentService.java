package com.example.demo.Services;

import java.time.LocalDate;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Appointment;
import com.example.demo.Repository.AppointmentRepository;

@Service
public class AppointmentService {

	@Autowired
	private AppointmentRepository appRepo;
	
	public Appointment addApp(Appointment app)
	{
		return appRepo.save(app);
	}
	
	public List<Appointment> addApps(List<Appointment> app)
	{
		return appRepo.saveAll(app);
	}
	
	public List<Appointment> findapp()
	{
		return appRepo.findAll();
	}
	
	public List<Map<String,Object>>  findappByDate(LocalDate appointmentDate)
	{
	
		return appRepo.findByDate(appointmentDate);
		  
	}
	
	public List<Map<String,Object>> findappByDocID(long id)
	{
		return appRepo.findByDocID(id);
		  
	}
	
	public List<Map<String , Object>>getdocdetails(long id)
	{
		return appRepo.findbydoc(id);
	}
	
	public Appointment findById (int id)
	{
		return appRepo.findById(id).orElse(null);
	}
	
	public String delete(int id)
	{
		appRepo.deleteById(id);
		return "Delete SuccessFully!!!! "+id;
	}
	
	public Appointment putApp(Appointment app)
	{
		Appointment ap=appRepo.findById(app.getAppointmentid()).orElse(null);
		ap.setDoctorId(app.getDoctorId());
		ap.setAppointmentStatus(app.getAppointmentStatus());
		ap.setPatientid(app.getPatientid());
		return appRepo.save(ap); 
	}
}
