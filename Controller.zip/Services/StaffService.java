package com.example.demo.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Staff;
import com.example.demo.Repository.StaffRepository;

@Service
public class StaffService {

	@Autowired
	private StaffRepository staRepo;
	
	public Staff saveStaff(Staff staff)
	{
		return staRepo.save(staff);
	}
	public List<Staff> saveStaffs(List<Staff> staff)
	{
		return staRepo.saveAll(staff);
	}
	public List<Staff> getStaff()
	{
		return staRepo.findAll();
	}
	public Staff getStaffById(long id)
	{
		return staRepo.findById(id).orElse(null);
	}
	public String deleteStaff(long id)
	{
		staRepo.deleteById(id);
		return "Delete SuccessFully!!!!!" +id;
	}
	public Staff updateStaff(Staff staff)
	{
		Staff ex =staRepo.findById(staff.getStaffid()).orElse(null);
		ex.setStaffName(staff.getStaffName());
		ex.setGender(staff.getGender());
		ex.setDateOfbirth(staff.getDateOfbirth());
		ex.setAddress(staff.getAddress());
		ex.setPhoneNumber(staff.getPhoneNumber());
		ex.setEmail(staff.getEmail());
		ex.setJobtitle(staff.getJobtitle());
		ex.setSalary(staff.getSalary());
		ex.setDepartmentid(staff.getDepartmentid());
		return staRepo.save(ex);
	}
}
