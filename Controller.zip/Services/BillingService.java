package com.example.demo.Services;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.example.demo.Billing;
import com.example.demo.Room;
import com.example.demo.Repository.BillingRepository;
import com.example.demo.Repository.RoomRepository;

@Service
public class BillingService {

	@Autowired
	private BillingRepository billRepo;
	
	@Autowired
	private RoomRepository romRepo;
	
	//Add New Bill
	
	public Billing addBill(Billing bill)
	{
		Room room = romRepo.findById(bill.getRoomnumber()).orElse(null);
		room.setRoomStatus(false);
		romRepo.save(room);
		return billRepo.save(bill);
	}
	
	//Add new List of bills
	public List<Billing> addBills(List<Billing> bill)
	{
		return billRepo.saveAll(bill);
	}
	
	//Get list of records from database
	public List<Billing> findBill()
	{
		return billRepo.findAll();
	}
	
	//Get record form database based on ID
	public Billing findById(long id) {
		return billRepo.findById(id).orElse(null);
	}
	
	//Delete record
	public String deleteBill(long id )
	{
		billRepo.deleteById(id); 
		return "Deleted Successfully!!!! "+ id;
	}
	
	//Update existing record
	public Billing putBill(Billing bill)
	{
		Room room1 = romRepo.findById(bill.getRoomnumber()).orElse(null);
		room1.setRoomStatus(true);
		romRepo.save(room1);
		
		Billing ex1 = billRepo.findById(bill.getBillingid()).orElse(null);
		//ex1.setDischaregeDate(LocalDate.now());
		ex1.setDischaregeDate(bill.getDischaregeDate());
		double n =(double) ChronoUnit.DAYS.between(ex1.getAppointmentDate(),ex1.getDischaregeDate());
		ex1.setTotalAmount(n*room1.getRoomRate());
		return billRepo.save(ex1);

	}
	
}
