package com.example.demo.Services;


	import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Doctor;
import com.example.demo.Repository.DoctorRepository;

	@Service
	public class DoctorService {

		@Autowired
		private DoctorRepository docRepo;
		
		public Doctor saveDoctor(Doctor doctor)
		{
			return docRepo.save(doctor);
		}
		public List<Doctor> saveDoctors(List<Doctor> doctor)
		{
			return docRepo.saveAll(doctor);
		}
		public List<Doctor> getDoctor()
		{
			return docRepo.findAll();
		}
		public Doctor getDoctorById(long id)
		{
			return docRepo.findById(id).orElse(null);
		}
		public String deleteDoctor(long id)
		{
			docRepo.deleteById(id);
			return "Delete SuccessFully!!!!!" +id;
		}
		public Doctor updateDoctor(Doctor doctor)
		{
			Doctor ex =docRepo.findById(doctor.getDoctorId()).orElse(null);
			ex.setDoctorName(doctor.getDoctorName());
			ex.setGender(doctor.getGender());
			ex.setDateOfbirth(doctor.getDateOfbirth());
			ex.setAddress(doctor.getAddress());
			ex.setPhoneNumber(doctor.getPhoneNumber());
			ex.setEmail(doctor.getEmail());
			ex.setDepartmentid(doctor.getDepartmentid());
			return docRepo.save(ex);
		}
	}


 
