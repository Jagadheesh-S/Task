package com.example.demo.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Room;
import com.example.demo.Repository.RoomRepository;

@Service
public class RoomService {

	@Autowired
	private RoomRepository romRepo;
	
	//save 
	public Room addRoom(Room room)
	{
		room.setRoomStatus(true);
		return romRepo.save(room);
	} 
	
	//save by list
	public List<Room> addRooms(List<Room> room)
	{
		for (Room room1 : room) {
	        room1.setRoomStatus(true);
	    }
		return romRepo.saveAll(room);
	}
	
	//get
	public List<Room> findRoom()
	{
		return romRepo.findAll();
	}
	
	//Get by id
	public Room findByIdRoom(long id)
	{
		return romRepo.findById(id).orElse(null);
	}
	
	//delete
	public String deleteById(long id)
	{
		romRepo.deleteById(id);
		return "Delete SuccessFully!!!! " + id;
	}
	
	
	//Update
	public Room putRoom(Room room)
	{
		Room ex=romRepo.findById(room.getRoomnumber()).orElse(null);
		ex.setRoomType(room.getRoomType());
		ex.setRoomRate(room.getRoomRate());
		ex.setRoomStatus(room.isRoomStatus());
		return romRepo.save(ex);
	}
}
