package com.example.demo.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Patient;
import com.example.demo.Repository.PatientRepository;

@Service
public class PatientService {

	@Autowired
	private PatientRepository patRepo;

	
	//Patient add
	public Patient addPatient(Patient patient)
	{
		return patRepo.save(patient);
	}
	
	//List Of patient add
	public List<Patient> addPatients(List<Patient> patient)
	{
		return patRepo.saveAll(patient);
		
	}
	
	//List Of Patient Retrieve
	public List<Patient> getPatient(){
		return patRepo.findAll();
	}
	
	//Retrieve Patient by ID
	public Patient getPatientById(long id)
	{
		return patRepo.findById(id).orElse(null);
	}
	
	//Delete Patient
	public String deletePatient(long id)
	{
		patRepo.deleteById(id);
		return "Delete SuccessFully!!!!!" +id;
	}
	
	//Update Patient
	public Patient updatePatient(Patient patient)
	{
		Patient ex = patRepo.findById(patient.getPatientid()).orElse(null);
		ex.setPatientName(patient.getPatientName());
		ex.setGender(patient.getGender());
		ex.setDateOfbirth(patient.getDateOfbirth());
		ex.setAddress(patient.getAddress());
		ex.setEmail(patient.getEmail());
		ex.setKinName(patient.getKinName());
		ex.setKinPhone(patient.getKinPhone());
		return patRepo.save(ex);
	}
}
