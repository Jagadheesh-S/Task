package com.example.demo.Services; 

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Department;
import com.example.demo.Repository.DepartmentRepository;

@Service
public class DepartmentService {
	
		
		@Autowired
		private DepartmentRepository depRepo;
		
		public Department saveDepartment(Department Dep) {
			return depRepo.save(Dep);
		}
		public List<Department> saveDepartments(List<Department> Deps) {
			return depRepo.saveAll(Deps);
		}
		public List<Department> getDepartment() {
			return depRepo.findAll();
		}
		public Department getDepartment(long id) {
			return depRepo.findById(id).orElse(null);
		}
		public String deleteDepartment(long id) {
			depRepo.deleteById(id);
			return "Delete Successfully! " +id;
		}
		public Department updatDepartment(Department Dep) {
			Department existing=depRepo.findById(Dep.getDepartmentid()).orElse(null);
			existing.setDepartment_Name(Dep.getDepartment_Name());
			existing.setDepartment_Description(Dep.getDepartment_Description());
			return depRepo.save(existing);
		}

	}